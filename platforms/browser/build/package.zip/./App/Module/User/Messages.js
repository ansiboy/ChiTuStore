define(["require", "exports"], function (require, exports) {
    requirejs(['css!content/User/Messages'], function () { });
    return function (page) {
    };
});
