define(["require", "exports"], function (require, exports) {
    return function (page) {
    };
});
